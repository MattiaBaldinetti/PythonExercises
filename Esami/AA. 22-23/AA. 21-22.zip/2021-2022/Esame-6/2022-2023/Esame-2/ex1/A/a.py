







                      turtle


cat dog




                                    zebra